"""The main mmdps package.

Add the parent folder of this folder to PYTHONPATH.
Modify rootconfig for specifiy configurations.
"""