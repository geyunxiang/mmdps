sh脚本，用于FSL预处理。

1.dwi_preprocess
预处理，去颅骨，涡流校正
2.dwi_calc_normalize
配准到标准空间，flirt