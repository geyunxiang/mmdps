tracking_plus是追踪需要的包，放到XXX\Anaconda3\envs\DTI\Lib\site-packages\下面即可。
DWI_pipeline是纤维束追踪要运行的FSL和python脚本，文件夹里有详细说明。

